<?php
require_once ("dbcontroller.php");
$db_handle = new DBController();
if (! empty($_POST["country_id"])) {
    $query = "SELECT * FROM tbl_faculty WHERE f_id = '" . $_POST["country_id"] . "'";
    $results = $db_handle->runQuery($query);
    ?>
<option value disabled selected>Select</option>
<?php
    foreach ($results as $state) {
        ?>
<option value="<?php echo $state["f_id"]; ?>"><?php echo $state["fname"]; ?></option>
<?php
    }
}
?>