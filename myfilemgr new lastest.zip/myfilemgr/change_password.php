<?php
session_start();
$_SESSION["userId"] = $_GET['id'];
$conn = mysqli_connect("localhost", "root", "", "myweb") or die("Connection Error: " . mysqli_error($conn));

if (count($_POST) > 0) {
    $result = mysqli_query($conn, "SELECT *from tbl_faculty WHERE f_id='" . $_SESSION["userId"] . "'");
    $row = mysqli_fetch_array($result);
    if ($_POST["currentPassword"] == $row["fpwd"]) {
        mysqli_query($conn, "UPDATE tbl_faculty set fpwd='" . $_POST["newPassword"] . "' WHERE f_id='" . $_SESSION["userId"] . "'");
        $message = "Password Changed";
    header("location:log_admin1.php");


    } else
        $message = "Current Password is not correct";
}
?>
<?php
?>

<html>
<head>
<title>Change Password</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
<script>
function validatePassword() {
var currentPassword,newPassword,confirmPassword,output = true;

currentPassword = document.frmChange.currentPassword;
newPassword = document.frmChange.newPassword;
confirmPassword = document.frmChange.confirmPassword;

if(!currentPassword.value) {
	currentPassword.focus();
	document.getElementById("currentPassword").innerHTML = "required";
	output = false;
}
else if(!newPassword.value) {
	newPassword.focus();
	document.getElementById("newPassword").innerHTML = "required";
	output = false;
}
else if(!confirmPassword.value) {
	confirmPassword.focus();
	document.getElementById("confirmPassword").innerHTML = "required";
	output = false;
}
if(newPassword.value != confirmPassword.value) {
	newPassword.value="";
	confirmPassword.value="";
	newPassword.focus();
	document.getElementById("confirmPassword").innerHTML = "not same";
	output = false;
} 	
return output;
}
</script>
</head>
<body>
    <form name="frmChange" method="post" action=""
        onSubmit="return validatePassword()">
        <div style="width: 100%;">
            
            <tr class="tableheader">
                    <td colspan="6">
    
<strong>Change Password</strong></td></cenetr>
                </tr><td  > </td>
                
            <div class="message"><?php if(isset($message)) { echo $message; } ?></div>
            <table border="0" cellpadding="10" cellspacing="0"
                width="500px"  height="0%" class="tblSaveForm">
                <tr>
                    <td width="40%"><label style="
    margin-left: 0px;
    margin-bottom: 24px;
">Current Password</label></td>
                    <td width="60%"><input type="password"
                        name="currentPassword" class="form-control" style="
    margin-left: -60px;
" /><span
                        id="currentPassword" class="required"></span></td>
                </tr>
                <tr>
                    <td><label style="
    margin-left: 0px;
    margin-bottom: 16px;
">New Password</label></td>
                    <td><input type="password" name="newPassword"
                        class="form-control" style="
    margin-left: -60px;
"/><span id="newPassword"
                        class="required"></span></td>
                </tr>
                <td><label style="
    margin-left: 0px;
    margin-bottom: 17px;
">Confirm Password</label></td>
                <td><input type="password" name="confirmPassword"
                    class="form-control" style="
    margin-left: -60px;
"/><span id="confirmPassword"
                    class="required"></span></td>
                </tr>
                    </table>
                <input type="submit" name="submit"
                        value="Change Password" class="btn-primary">
                        </table>
        </div>
    </form>
</body>
</html>