


<!--=================================
 header --> 
<form action="registersql.php" method="post">
<!--=================================
 inner-intro-->

<section class="inner-intro bg bg-fixed bg-overlay-black-60" style="background-image:url(images/bg/inner-bg-1.jpg);">
  <div class="container">
    <div class="row intro-title text-center">
      <div class="col-md-12">
        <div class="section-title">
          <h1 class="position-relative divider">register 1<span class="sub-title w-100">register 1</span></h1>
        </div>
      </div>
      <div class="col-md-12 mt-7">
        <ul class="page-breadcrumb">
          <li><a href="index-default.html"><i class="fa fa-home"></i> Home</a> <i class="fa fa-angle-double-right"></i></li>
          <li><a href="register.html">Pages</a> <i class="fa fa-angle-double-right"></i></li>
          <li><span>register 1</span> </li>
        </ul>
      </div>
    </div>
  </div>
</section>

<!--=================================
 inner-intro--> 

<!--=================================
 login-->

<section class="login-form register-img dark-bg page-section-ptb" style="background: url(images/pattern/04.png) no-repeat 0 0; background-size: cover;">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="login-1-form register-1-form clearfix text-center">
          <h4 class="title divider-3 text-white mb-3">sign up</h4>
          <form action="registersql.php" method="post">
		  <div class="section-field mb-3">
            <div class="field-widget"> <i class="glyph-icon flaticon-user"></i>
              <input id="student_id" name="student_id" type="text" placeholder="ID">
            </div>
          </div>
		  <div class="section-field mb-3">
            <div class="field-widget"> <i class="glyph-icon flaticon-user"></i>
              <input id="Firstname" type="text" name="student_name" placeholder="Name">
            </div>
          </div>
		  <div class="section-field mb-3">
            <div class="field-widget"> <i class="fa fa-envelope-o" aria-hidden="true"></i>
              <input id="email" class="email" type="email" placeholder="Email" name="student_email">
            </div>
          </div>
		  <div class="section-field mb-3">
            <div class="field-widget"> <i class="glyph-icon flaticon-padlock"></i>
              <input id="Password" class="Password" type="password" placeholder="Password" name="student_pwd">
            </div>
          </div>
		  <div class="section-field mb-3">
            <div class="field-widget"> <i class="glyph-icon flaticon-padlock"></i>
              <input id="student_gender" class="Password" type="text" placeholder="Gender" name="student_gender">
            </div>
          </div>
          <div class="section-field mb-3">
            <div class="field-widget"> <i class="glyph-icon flaticon-user"></i>
              <input id="student_contact" type="text" name="student_contact" placeholder="Contact">
            </div>
          </div>
		  
          
          <div class="section-field mb-3">
            <div class="field-widget"> <i class="glyph-icon flaticon-padlock"></i>
              <input id="student_DOB" class="" type="datetime" placeholder="DOB" name="student_DOB">
            </div>
          </div>
		  <div class="section-field mb-3">
            <div class="field-widget"> <i class="glyph-icon flaticon-padlock"></i>
              <input class="form-control " id="photo" type="file" name="photo" required="" aria-required="true">
            </div>
          </div>
          <div class="section-field mb-3">
            <div class="field-widget"> <i class="fa fa-graduation-cap" aria-hidden="true"></i>
              <input id="Collagename" type="text" name="clg_id" placeholder="Collage name">
            </div>

          <div class="section-field mb-3">
            <div class="field-widget"> <i class="glyph-icon flaticon-padlock"></i>
              <input id="course_id" class="" type="text" placeholder="Course id" name="course_id">
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="section-field text-uppercase text-center mt-2"> <span> <input type="submit" value="submit" class="button  btn-lg btn-theme full-rounded animated right-icn"> <i class="glyph-icon flaticon-hearts" aria-hidden="true"></i></div>
		  <div class="clearfix"></div>
          <div class="section-field mt-2 text-center text-white">
            <p class="lead mb-0">Have an account? <a class="text-white" href="login.html"><u>Sign In!</u> </a></p>
          </div>
        </div>
		  </form>
	  </div>
    </div>
  </div>
</section>
<!--=================================
 login--> 

<!--=================================
footer -->

<footer class="text-white text-center">
  <div class="footer-widget">
    <div class="container">
      <div class="row  justify-content-center">
        <div class="col-md-8">
          <div class="footer-logo mb-2"> <img class="img-center" src="images/footer-logo.png" alt="" /> </div>
          <div class="social-icons color-hover">
            <ul>
              <li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li class="social-dribbble"><a href="#"><i class="fa fa-dribbble"></i></a></li>
              <li class="social-gplus"><a href="#"><i class="fa fa-google-plus"></i></a></li>
              <li class="social-youtube"><a href="#"><i class="fa fa-youtube"></i></a></li>
            </ul>
          </div>
          <p class="text-white">© 2018  - Cupid Love All Right Reserved </p>
        </div>
      </div>
    </div>
  </div>
</footer>

<!--=================================
footer --> 

<!--=================================
Color Customizer -->
<div class="style-customizer closed">
  <div class="buy-button"> <a class="opener" href="#"><i class="fa fa-cog fa-spin"></i></a> </div>
  <div class="clearfix content-chooser">
    <div class="section-title">
      <h4 class="title">Color Schemes</h4>
    </div>
    <p>Which theme color you want to use? Here are some predefined colors.</p>
    <ul class="styleChange clearfix">
      <li class="skin-default selected" title="Default" data-style="skin-default" ></li>
      <li class="skin-green" title="Green" data-style="skin-green"></li>
      <li class="skin-red" title="Red" data-style="skin-red" ></li>
      <li class="skin-yellow" title="Yellow" data-style="skin-yellow"></li>
      <li class="skin-lightgreen" title="Light Green" data-style="skin-lightgreen"></li>
      <li class="skin-blue" title="Blue" data-style="skin-blue"></li>
      <li class="skin-orange" title="Orange" data-style="skin-orange"></li>
      <li class="skin-darkblue" title="Dark Blue" data-style="skin-darkblue"></li>
      <li class="skin-cyan" title="cyan" data-style="skin-cyan"></li>
      <li class="skin-gold" title="Gold" data-style="skin-gold"></li>
    </ul>
    <ul class="resetAll clearfix">
      <li><a target="_blank" class="button" href="#"><span>Purchase Now</span></a></li>
      <li><a class="button-reset button" href="#"><span>Reset All</span></a></li>
    </ul>
  </div>
</div>
<div id="back-to-top"><a class="top arrow" href="#top"><i class="fa fa-level-up"></i></a></div>

<!--=================================
 jquery --> 

<!-- jquery  --> 
<script type="text/javascript" src="js/jquery.min.js"></script> 
<script type="text/javascript" src="js/popper.min.js"></script> 

<!-- bootstrap --> 
<script type="text/javascript" src="js/bootstrap.min.js"></script> 
<script type="text/javascript" src="js/bootstrap-select.min.js"></script> 

<!-- appear --> 
<script type="text/javascript" src="js/jquery.appear.js"></script> 

<!-- appear --> 
<script type="text/javascript" src="js/jquery.appear.js"></script> 

<!-- Menu --> 
<script type="text/javascript" src="js/mega-menu/mega_menu.js"></script> 

<!-- style customizer  --> 
<script type="text/javascript" src="js/style-customizer.js"></script> 

<!-- custom --> 
<script type="text/javascript" src="js/custom.js"></script>
</form>
</body>

<!-- Mirrored from themes.potenzaglobalsolutions.com/html/cupid-love-dating-website-html5-template/cupid-love/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 18 Aug 2018 17:07:21 GMT -->


</html>
