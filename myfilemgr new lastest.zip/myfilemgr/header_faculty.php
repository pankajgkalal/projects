<?php
session_start();
if($_SESSION["log"]) {
?>

<?php
}
else
{
header ("location:signup.php");	
}
?>
<?php
	

	  $Email=$_SESSION['email'];//username
	 $password=$_SESSION['password'];//password 
  $name=$_SESSION['fname'];//password 
 $fid=$_SESSION['f_id'];//password 
 
 //$sem=$_SESSION['sem'];
 //$name=$_SESSION['sname'];
   //$class=$_SESSION['class'];

 

?> 

<html>
<title>File|Mgr</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
<link href="globe.png" rel="shortcut icon">
<?php
date_default_timezone_set("Asia/Calcutta");
//echo date_default_timezone_get();
?>


<?php
$conn=new PDO('mysql:host=localhost; dbname=myweb', 'root', '') or die(mysql_error());
if(isset($_POST['submit'])!=""){
  $name=$_FILES['photo']['name'];
  $size=$_FILES['photo']['size'];
  $type=$_FILES['photo']['type'];
  $temp=$_FILES['photo']['tmp_name'];
  $date = date('Y-m-d');
 $course=$_POST['course'];
$sem=$_POST['sem'];
$class=$_POST['class'];

$info=$_POST['info'];

 $caption=$_POST['caption'];
  $link=$_POST['link'];
  
  move_uploaded_file($temp,"files/".$name);

$query=$conn->query("INSERT INTO upload (name,date,course,sem,info,class) VALUES ('$name','$date','$course','$sem','$info','$class')");
if($query){
header("location:index.php");
}
else{
die(mysql_error());
}
}
?>


</head>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
<link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css"/>
</head>
<script src="js/jquery.js" type="text/javascript"></script>
<script src="js/bootstrap.js" type="text/javascript"></script>

<script type="text/javascript" charset="utf-8" language="javascript" src="js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="js/DT_bootstrap.js"></script>
<?php include('dbcon.php'); ?>
<style>
.table tr th{
	
	border:#eee 1px solid;
	
	position:relative;
	#font-family:"Times New Roman", Times, serif;
	font-size:12px;
	text-transform:uppercase;
	}
	table tr td{
	
	border:#eee 1px solid;
	color:#000;
	position:relative;
	#font-family:"Times New Roman", Times, serif;
	font-size:12px;
	
	text-transform:uppercase;
	}
	
#wb_Form1
{ 
   border: 0px #000 solid;
  
}
#photo
{
   border: 1px #A9A9A9 solid;
   background-color: #00BFFF;
   color: #fff;
   font-family:Arial;
   font-size: 20px;
}
	</style>
	


	<div class="alert alert-info">
                                 <div style="float:left;width:50%;margin-top:-10px">
                               <?php
							   echo  $name=$_SESSION['fname'];//username
							
							   ?>
							  
                            </div>
							<div style="float:left;width:34%;margin-top:-10px">
                              
							LJMCA

							</div>
							<div style="float:left;width:15%;margin-top:-10px;margin-right:-10px">
                              
					<a href="view_assign.php">View Assignments</a>
					<a href="logoutf.php">Logout</a>


<a href="change_password.php?id=<?php echo $fid ?>" class="fa fa-key"> Change Password </a>
							</div>
	                        </div>
