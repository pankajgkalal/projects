<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>LJMCA</title>
      <!-- Bootstrap core css1-->
      <link href="css1/bootstrap.min.css" rel="stylesheet">
      <!-- Custom fonts for this template-->
      <link href="css1/all.min.css" rel="stylesheet" type="text/css">
      <!-- Custom styles for this template-->
      <link href="css1/sb-admin.css" rel="stylesheet">
   </head>
   <body style="background-color:#9c9c9c;">
      <div class="container" style="padding:10px">
         <div class="card card-login mx-auto mt-5">
            <div class="card-header">Student Login</div>
            <div class="card-body">
               <form action="checkall.php" method="post">
                  <div class="form-group">
                     <div class="form-label-group" style="margin:20px">
                        <input type="email"  name="email"id="inputEmail" class="form-control" placeholder="Email address" required="required" autofocus="autofocus">
                        <label for="inputEmail">Email address</label>
                     </div>
                  </div>
                  <div class="form-group">
                     <div class="form-label-group" style="margin:20px">
                        <input type="password"  name="password" id="inputPassword" class="form-control" placeholder="Password" required="required">
                        <label for="inputPassword">Password</label>
                     </div>
                  </div>
                  <div class="form-group" style="margin:20px">
                     <div class="checkbox">
                        <label>
                        <input type="checkbox" value="remember-me">
                        Remember Password
                        </label>
                     </div>
                  </div>
                  <div class="form-group" style="text-align:center">
                     <input type="submit" style="text-align:center" value ="login"class="btn btn-primary " ></a>
                  </div>
               </form>
               <div class="text-center">
                  <a class="d-block small mt-3" href="signup.php">Register an Account</a>
                  <a class="d-block small" href="log_admin1.php">faculty Login</a>
               </div>
            </div>
         </div>
      </div>
      <!-- Bootstrap core JavaScript-->
      <script src="css1/jquery.min.css1"></script>
      <script src="css1/bootstrap.bundle.min.css"></script>
      <!-- Core plugin JavaScript-->
      <script src="css1/jquery.easing.min.css"></script>
   </body>
</html>