<?php

$conn = mysqli_connect("localhost","root","","myweb");
$student_id =$_POST['En_no'];
$student_name = $_POST['student_name'];
//$student_gender = $_POST['student_gender'];
$student_email = $_POST['email'];
$student_pwd = $_POST['psw'];
//$student_contact = $_POST['student_contact'];
//$student_DOB = $_POST['student_DOB'];
$sem = $_POST['sem'];
$course = $_POST['course'];
$class = $_POST['class'];

/*$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["photo"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
*
echo '<pre>';
if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_file)) {
    echo "File is valid, and was successfully uploaded.\n";
} else {
    echo "Possible file upload attack!\n";
}
	
*/
if(mysqli_query($conn,"Insert into tbl_stud(enroll_no,sname,semail,spwd,sem,course,class )values('$student_id','$student_name','$student_email','$student_pwd','$sem','$course','$class')"))
{
	echo "Done";
	header ("location:log_admin.php");
}
else
{
	echo mysqli_error($conn);
}


?>