

<?php include('navbar.php'); 

 $id=$_GET['id'];

?>

					<!--		<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered">
		
			<tr><td>
					<input type="file" name="photo" id="photo"  required="required">
					Information about file:<input type="text" name="info" class="form-control"></td>
					<td><label text="course" class="form-">course</label><select class="form-control" name="course">
					
					<option>--select--</option>				
					<option value="MCA">MCA</option>
					<option value="I-MCA">IMCA</option>
					
					</select></td>
					<td><label text="course" class="form-">SEM</label><select class="form-control" name="sem">
				<option>--select--</option>				
				<option value="sem-1">sem-1</option>
				
				<option value="sem-2">sem-2</option><option value="sem-3">sem-3</option><option value="sem-4">sem-4</option>
				<option value="sem-4">sem-5</option><option value="sem-4">sem-6</option>
				</select></td>
					<td><label text="course" class="form-">class</label><select class="form-control" name="class">
				<option>--select--</option>				
				<option value="B">A</option>
				
				<option value="B">B</option><option value="C">C</option>
				</select></td>
					
					<td><input type="submit" class="btn btn-danger" value="SUBMIT" name="submit">
		
		</form></tr></td></table>
-->						
						<div class="col-md-18">
	<div class="container-fluid" style="margin-top:0px;">
   <div class = "row">
		<div class="panel panel-default">
			<div class="panel-body">
				<div class="table-responsive">


							<form method="post" action="markssql.php" >
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-condensed" id="example">
                            
                            <thead>
						
                                <tr style="background-color:grey;color:white">
                                    
                                    <th>FILE NAME</th>
                                   <th>Date</th>
<th>Description</th>
<th>Course</th><th>Sem</th>				
		<th>Download</th>
				<th>Remove</th>
				
				<th>Assignment</th>
		<th>Marks</th>
        <th>Submit</th>
                  
		 </tr>
                            </thead>
                            <tbody>
							<?php 

?>
<?php
						$query=mysql_query("select * from upload_student u ,tbl_stud s where assign_id ='$id' && u.stud_id = s.sid")or die(mysql_error());
						while($row=mysql_fetch_array($query)){
							   $aid=$row['id']; 
							    $sid=$row['sid']; 
$_SESSION["aid"] = $aid;
 $_SESSION["sid"]=$sid;
 //$_SESSION["sid"]=$id;

							  ?>


							
										<tr>
										
                                             <td><?php echo $row['uname'] ?></td>
                                         <td><?php   $date= $row["udate"];
			echo date('d-m-Y', strtotime($date));?>
										</td>
										 <td><?php echo $row['sname'] ?></td>
										 
										 <td><?php echo $row['course'] ?></td>
										 
										 <td><?php echo $row['sem'] ?></td>
								
								<td>
				<a href="download.php?filename=<?php echo $name;?>" title="click to download"><span class="glyphicon glyphicon-paperclip" style="font-size:20px; color:blue"></span></a>
				</td>
				<td>
				<a href="delete.php?del=<?php echo $row['id']?>"><span class="glyphicon glyphicon-trash" style="font-size:20px; color:red"></span></a>
				</td>
				<td>
				
				<a href="files/<?php echo $row['uname']?>" target="_blank">View</a>	
				
					</td>
	
				<td><label text="course" class="form-">enter marks</label>
				<input type="text" placeholder="Out of 10"  name="marks" class="form-control" ></input>
			
	</td>
       	</td>
			<td><label text="course" class="form-">SUBMIT</label>
		<input type="submit"class="btn-danger form-control">	
	</td>
                         </tr>
                         
						          <?php } ?>
                            </tbody>
                        </table>
						
                              
                               
								
                            </div>
          
</form>

        </div>
        </div>
        </div>
    
<div class="footer-fixed">
					<div class="pull-right">
						<ul class="list-inline">
							  <li>Design & Developed By <a href="https://www.facebook.com/panakaj.kalal">Pankaj kalal</a> & <a href="https://www.facebook.com/lal.saroj.1">Sarojkumar Lal</a></li>
           
									</ul>
					</div>
					<div> <strong>Copyright</strong>  &copy; LJMCA </div>
				</div>
			</div>
</div>

</body>
</html>

