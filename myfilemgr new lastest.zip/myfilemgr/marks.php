<?php include('navbar.php'); 

 $id=$_GET['id'];

?>
					<!--		<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered">
		
			<tr><td><form enctype="multipart/form-data"  action="" id="wb_Form1" name="form" method="post">
				
					<input type="file" name="photo" id="photo"  required="required">
					Information about file:<input type="text" name="info" class="form-control"></td>
					<td><label text="course" class="form-">course</label><select class="form-control" name="course">
					
					<option>--select--</option>				
					<option value="MCA">MCA</option>
					<option value="I-MCA">IMCA</option>
					
					</select></td>
					<td><label text="course" class="form-">SEM</label><select class="form-control" name="sem">
				<option>--select--</option>				
				<option value="sem-1">sem-1</option>
				
				<option value="sem-2">sem-2</option><option value="sem-3">sem-3</option><option value="sem-4">sem-4</option>
				<option value="sem-4">sem-5</option><option value="sem-4">sem-6</option>
				</select></td>
					<td><label text="course" class="form-">class</label><select class="form-control" name="class">
				<option>--select--</option>				
				<option value="B">A</option>
				
				<option value="B">B</option><option value="C">C</option>
				</select></td>
					
					<td><input type="submit" class="btn btn-danger" value="SUBMIT" name="submit">
		
		</form></tr></td></table>
-->						
						<div class="col-md-18">
	<div class="container-fluid" style="margin-top:0px;">
   <div class = "row">
		<div class="panel panel-default">
			<div class="panel-body">
				<div class="table-responsive">


							<form method="post" action="delete.php" >
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-condensed" id="example">
                            
                            <thead>
						
                                <tr style="background-color:grey;color:white">
                                    
                                    <th style="color:">Assignment</th>
                                    <th>Student upload_assignment</th>
                                   <th>student name</th>
<th>subject</th>
<th>sem</th><th>Course</th>			
				
<th>Marks</th>	

<th>Submit marks</th>		
                                </tr>
                            </thead>
                            <tbody>
							<?php 

?>
<?php
						$query=mysql_query("select * from upload_student u ,tbl_stud s where assign_id ='$id' && u.stud_id = s.sid")or die(mysql_error());
						while($row=mysql_fetch_array($query)){
							?>


							
										<tr>
			<td><label text="course" class="form-">Assignment</label><select class="form-control" name="Assignment">
					
					<option>--select--</option>				
					<?php

$conn = mysqli_connect("localhost","root","","myweb");
if($result = mysqli_query($conn,"select * from upload_assignment"))
{
 while($row=$result->fetch_assoc())
 {
?>
<option  value="<?php  echo $row["id"] ?>"><?php  echo $row["name"] ?></option>


<?php
}
}


?>
</select>		
		
					<td><label text="course" class="form-"> Student Uplaoded Assignment</label><select class="form-control" name="Assignment">
					
					<option>--select--</option>				
					<?php

$conn = mysqli_connect("localhost","root","","myweb");
if($result = mysqli_query($conn,"select * from upload_student u ,tbl_stud s where assign_id ='$id' && u.stud_id = s.sid"))
{
 while($row=$result->fetch_assoc())
 {
?>
<option  value="<?php  echo $row["id"] ?>"><?php  echo $row["uname"] ?></option>


<?php
}
}


?>
</select> 

					</select></td>
					<td><label text="course" class="form-">Student</label><select class="form-control" name="Faculty">
				<option>--select--</option>				
					<?php

$conn = mysqli_connect("localhost","root","","myweb");
if($result = mysqli_query($conn,"select  *  from upload_student u ,tbl_stud s where assign_id ='$id' && u.stud_id = s.sid"))
{
 while($row=$result->fetch_assoc())
 {
?>
<option  value="<?php  echo $row["sid"] ?>"><?php  echo $row["sname"] ?></option>


<?php
}
}


?>
				
				</select></td>
					<td><label text="course" class="form-">Subject</label><select class="form-control" name="Subject">
				<option value="0">--select--</option>				
									<?php

$conn = mysqli_connect("localhost","root","","myweb");
if($result = mysqli_query($conn,"Select * from tbl_subject"))
{
 while($row=$result->fetch_assoc())
 {
?>
<option  value="<?php  echo $row["s_id"] ?>"><?php  echo $row["sname"] ?></option>


<?php
}
}
?>  

				<td><label text="course" class="form-">SEM</label><select class="form-control" name="Subject">
				<option value="0">--select--</option>				
									<?php

$conn = mysqli_connect("localhost","root","","myweb");
if($result = mysqli_query($conn,"Select *  from upload_student u ,tbl_stud s where assign_id ='$id' && u.stud_id = s.sid "))
{
 while($row=$result->fetch_assoc())
 {
?>
<option  value="<?php  echo $row["s_id"] ?>"><?php  echo $row["sem"] ?></option>


<?php
}
}
?>

				<td><label text="course" class="form-">Course</label><select class="form-control" name="Subject">
				<option value="0">--select--</option>				
									<?php

$conn = mysqli_connect("localhost","root","","myweb");
if($result = mysqli_query($conn,"Select *  from upload_student u ,tbl_stud s where assign_id ='$id' && u.stud_id = s.sid "))
{
 while($row=$result->fetch_assoc())
 {
?>
<option  value="<?php  echo $row["s_id"] ?>"><?php  echo $row["course"] ?></option>


<?php
}
}
?>

				<td><label text="course" class="form-">enter marks</label>
				<input type="text" placeholder="Out of 10" class="form-control">
			
	</td>
			<td><label text="course" class="form-">SUBMIT</label>
		<input type="submit"class="btn-danger form-control">	
	</td>
                                </tr>
                         
						          <?php } ?>
                            </tbody>
                        </table>
						
                              
                               
								
                            </div>
          
</form>

        </div>
        </div>
        </div>
    </div>


</body>
</html>

