<?php

$conn = mysqli_connect("localhost","root","","project_h");
$student_id =$_POST['student_id'];
$student_name = $_POST['student_name'];
$student_gender = $_POST['student_gender'];
$student_email = $_POST['student_email'];
$student_pwd = $_POST['student_pwd'];
$student_contact = $_POST['student_contact'];
$student_DOB = $_POST['student_DOB'];
$clg_id = $_POST['clg_id'];
$course_id = $_POST['course_id'];

$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["photo"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

echo '<pre>';
if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_file)) {
    echo "File is valid, and was successfully uploaded.\n";
} else {
    echo "Possible file upload attack!\n";
}
	

if(mysqli_query($conn,"Insert into tbl_student(student_id,student_name,student_gender,student_email,student_pwd,student_contact,student_DOB,photo,clg_id,course_id )values('$student_id','$student_name','$student_gender','$student_email','$student_pwd','$student_contact','$student_DOB','$target_file','$clg_id','$course_id')"))
{
	echo "Done";
	header ("location:register.php");
}
else
{
	echo mysqli_error($conn);
}


?>