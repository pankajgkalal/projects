<?php
   session_start();
   if($_SESSION["log"]) {
   ?>
<?php
   }
   else
   {
   header ("location:signup.php");	
   }
   ?>
<?php
   $Email=$_SESSION['email'];//username
   $password=$_SESSION['password'];//password 
   $name=$_SESSION['fname'];//password 
   $fid=$_SESSION['f_id'];//password 
   
   //$sem=$_SESSION['sem'];
   //$name=$_SESSION['sname'];
   //$class=$_SESSION['class'];
   
   
   
   ?> 
<?php
   date_default_timezone_set("Asia/Calcutta");
   //echo date_default_timezone_get();
   ?>
<?php
   $conn=new PDO('mysql:host=localhost; dbname=myweb', 'root', '') or die(mysql_error());
   if(isset($_POST['submit'])!=""){
     $name=$_FILES['photo']['name'];
     $size=$_FILES['photo']['size'];
     $type=$_FILES['photo']['type'];
     $temp=$_FILES['photo']['tmp_name'];
     $date = date('Y-m-d');
    $course=$_POST['course'];
   $sem=$_POST['sem'];
   $class=$_POST['class'];
   
   $info=$_POST['info'];
   
    $caption=$_POST['caption'];
     $link=$_POST['link'];
     
     move_uploaded_file($temp,"files/".$name);
   
   $query=$conn->query("INSERT INTO `upload`(`name`, `date`, `course`, `sem`, `info`, `class`) VALUES ('$name','$date','$course','$sem','$info','$class')");
   if($query){
   header("location:index.php");
   }
   else{
   die(mysql_error());
   }
   }
   ?>
<!DOCTYPE html>
<html>
   <head>
      <title>File Manager</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
      <link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
      <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css1/navbar_css.css">
      <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css"/>
      <script src="js/jquery.js" type="text/javascript"></script>
      <script src="js/bootstrap.js" type="text/javascript"></script>
      <script type="text/javascript" charset="utf-8" language="javascript" src="js/jquery.dataTables.js"></script>
      <script type="text/javascript" charset="utf-8" language="javascript" src="js/DT_bootstrap.js"></script>
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <!-- slimscroll -->
      <link href="css/jquery.slimscroll.css" rel="stylesheet">
      <!-- Fontes -->
      <link href="css/font-awesome.min.css" rel="stylesheet">
      <link href="css/glyphicons.css" rel="stylesheet">
      <link href="css/simple-line-icons.css" rel="stylesheet">
      <!-- all buttons css -->
      <link href="css/buttons.css" rel="stylesheet">
      <!-- animate css -->
      <link href="css/animate.css" rel="stylesheet">
      <!-- The Wolf main css -->
      <link href="css/main.css" rel="stylesheet">
      <!-- theme css -->
      <link href="css/theme.css" rel="stylesheet">
      <!-- media css for responsive  -->
      <link href="css/main.media.css" rel="stylesheet">
      <!-- demo  -->
      <link href="css/appdemo.css" rel="stylesheet">
   </head>
   <body>
      <?php include('dbcon.php'); ?>
      <div class="topnav">
         <a class="" href="index.php">Home</a>
         <a href="assignment.php">Assignment</a>
         <div class="topnav-right">
            <div class="dropdown">
               <a href="#"> <?php echo  $name=$_SESSION['fname'];//username?>
               <!--<a href="change_password.php?id=<?php echo $fid ?>">Change Password</a>
               --><a href="logoutf.php"><b>Logout</b></a>
               </a>
            </div>
         </div>
      </div>
      </div>
     
        