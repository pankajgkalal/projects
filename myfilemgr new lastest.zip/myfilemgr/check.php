<?php

// username and password sent from form 
$email=$_POST['email']; 

$password=$_POST['password']; 

 
session_start();

$con=mysqli_connect("localhost","root","","myweb");//mysqli("localhost","username of database","password of database","database name")

// To protect MySQL injection (more detail about MySQL injection)

$result=mysqli_query($con,"SELECT * FROM `tbl_faculty` WHERE `femail`='$email'  && `fpwd`='$password'");



// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);
// If result matched $myusername and $mypassword, table row must be 1 row


if($count==1){
$result=mysqli_fetch_assoc($result);
$name = $result['fname'];
$fid = $result['f_id'];

//$sem=$result['sem'];
//$name = $result['sname'];
//$class = $result['class'];

//$name = $result['name'];

//page link on the basis of user role you can add more  condition on the basis of ur roles in db
if($role =='admin'){
 $link = 'index.php';
 }
elseif($role =='user'){
 $link = 'studentview.php';
 }
 elseif($role =='faculty'){
 $link = 'facltyview.php';
 }

 
// SESSION Register $myusername, $mypassword and redirect to file "login_success.php"
$_SESSION['log']=1;
$_SESSION['login']=1;
$_SESSION["email"] = $email;
$_SESSION["password"] = $password;
$_SESSION["f_id"] = $fid;

//$_SESSION["level"] = $role;
echo $_SESSION["fname"]=$name;


header("Location:index.php");
}

else
{ 
echo "<script>
 alert('pls enter correct username and password');
 window.location.href='log_admin1.php';
 </script>";

	}
	

?>
