<?php include('navbars.php'); ?>
<?php require_once("dbcontroller.php");
   $db_handle = new DBController();
   
   $query ="Select * from upload_assignment where sem='$sem' && course='$course' && class='$class'";
   $results = $db_handle->runQuery($query);
   ?>
<script>
   function getState(val) {
   	$.ajax({
   	type: "POST",
   	url: "getState.php",
   	data:'country_id='+val,
   	success: function(data){
   		$("#state-list").html(data);
   		getCity();
   	}
   	});
   }
   
   
   function getCity(val) {
   	$.ajax({
   	type: "POST",
   	url: "getCity.php",
   	data:'state_id='+val,
   	success: function(data){
   		$("#city-list").html(data);
   	}
   	});
   }
</script>
<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered">
   <tr>
      <td>
         <form enctype="multipart/form-data"  action="" id="wb_Form1" name="form" method="post">
            <input type="file" name="photo" id="photo"  required="required">
            <b>Information about file<b>:<input type="text" name="info" class="form-control">
      </td>
      <td>
      <label text="course" class="form-">Assignment</label>
      <select name="Assignment" id="course" class="form-control" onChange="getState(this.value);">
      <option value disabled selected>Select</option>
      <?php
         foreach($results as $country) {
         ?>
      <option value="<?php echo $country["f_id"]; ?>"><?php echo $country["name"]; ?></option>
      <?php
         }
         ?>
      </select>
      </td>
      <td>
      <label text="course" class="form-">Faculty:</label>
      <select name="Faculty" id="state-list" class="form-control" >
      <option value="">Select</option>
      </select>
      </td>
      <td>	<label text="course" class="form-">Subject:</label>
      <select name="Subject" id="" class="form-control" onChange="getCity(this.value);">
      <option value="0">Select Subject</option>
      <?php
         $conn = mysqli_connect("localhost","root","","myweb");
         if($result2 = mysqli_query($conn,"Select * from tbl_subject"))
         {
          while($row2=$result2->fetch_assoc())
          {
         
         	?>
      <option value="<?php  echo $row2["sname"] ?>"><?php  echo $row2["sname"] ?></option>
      <?php
         }
         }
         
         ?>
      
	  </select>
      </td>
      <td><input type="submit" class="btn btn-danger" value="submit" name="submit" style="margin-top:20px">
      </form>
   </tr>
   </td>
</table>
<!-- table coding ends -->		
<div class="col-md-18">
   <div class="container-fluid" style="margin-top:0px;">
      <div class = "row">
         <div class="panel panel-default">
            <div class="panel-body">
               <div class="table-responsive">
                  <form method="post" action="delete.php" >
                     <table cellpadding="0" cellspacing="0" border="0" class="table table-condensed" id="example">
                        <thead>
                           <tr style="background-color:grey;color:white">
                              <th>FILE NAME</th>
                              <th>Date</th>
                              <th>Description</th>
                              <th> View Marks	</th>
                              <th>download~</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php
                              $query=mysql_query("select * from upload WHERE sem='$sem' && course='$course' && class='$class' ")or die(mysql_error());
                              while($row=mysql_fetch_array($query)){
                              $id=$row['id'];
                              $name=$row['name'];
                              $date=$row['date'];
							  
                              ?>
                           <tr>
                              <td><?php echo $row['name'] ?></td>
                              <td>
                                 <?php   $date= $row["date"];
                                    echo date('d-m-Y', strtotime($date));?>
                              </td>
                              <td><?php echo $row['info'] ?></td>
                              <td><a href="studentmarks.php?id=<?php echo $sid ?>" >View Marks</a></td>
                              <td>
                                 <a href="download.php?filename=<?php echo $name;?>" title="click to download"><span class="glyphicon glyphicon-paperclip" style="font-size:20px; color:blue"></span></a>
                              </td>
                              <?php } ?>
                           </tr>
                        </tbody>
                     </table>
               </div>
               </form>
            </div>
         </div>
      </div>
      <div class="footer-fixed">
         <div class="pull-right">
            <ul class="list-inline">
                 <li>Design & Developed By <a href="https://www.facebook.com/panakaj.kalal">Pankaj kalal</a> & <a href="https://www.facebook.com/lal.saroj.1">Sarojkumar Lal</a></li>
           
            </ul>
         </div>
         <div> <strong>Copyright</strong>  &copy; LJMCA </div>
      </div>
   </div>
</div>
</body>
</html>