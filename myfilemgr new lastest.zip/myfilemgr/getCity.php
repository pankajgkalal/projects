<?php
require_once ("dbcontroller.php");
$db_handle = new DBController();
if (! empty($s=$_POST["state_id"])) {
	echo $s;
    $query = "SELECT * FROM  tbl_subject WHERE s_id = '" . $_POST["state_id"] . "' ";
    $results = $db_handle->runQuery($query);
    ?>
<option value disabled selected>Select</option>
<?php
    foreach ($results as $city) {
        ?>
<option value="<?php echo $city["s_id"]; ?>"><?php echo $city["sname"]; ?></option>
<?php
    }
}
?>