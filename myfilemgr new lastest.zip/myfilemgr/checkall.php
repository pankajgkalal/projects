<?php

// username and password sent from form 
$email=$_POST['email']; 

$password=$_POST['password']; 

 //$course=$_POST['course']; 
 //$sem=$_POST['sem']; 
session_start();

$con=mysqli_connect("localhost","root","","myweb");//mysqli("localhost","username of database","password of database","database name")

// To protect MySQL injection (more detail about MySQL injection)

$result=mysqli_query($con,"SELECT * FROM `tbl_stud` WHERE `semail`='$email'  && `spwd`='$password'");



// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);
// If result matched $myusername and $mypassword, table row must be 1 row


if($count==1)
{
$result=mysqli_fetch_assoc($result);
$course = $result['course'];
$sem=$result['sem'];
$name = $result['sname'];
$class = $result['class'];
$id = $result['sid'];

$_SESSION['log']=1;
$_SESSION['login']=1;
$_SESSION["email"] = $email;
$_SESSION["password"] = $password;
 $_SESSION["sem"]=$sem;
 $_SESSION["sid"]=$id;

 // echo $_SESSION["sname"]=$sname;
echo $_SESSION["sname"]=$name;
echo $_SESSION["course"]=$course;

echo $_SESSION["class"]=$class;

header("Location:studentview.php");
}
else
{ 
echo "<script>
 alert('pls enter correct username and password');
 window.location.href='log_admin.php';
 </script>";

	}
	

?>
