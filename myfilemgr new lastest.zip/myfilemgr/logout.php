<?php
 session_start();
 session_destroy();
 session_cache_expire(2);
header ("location:log_admin.php");

 ?>