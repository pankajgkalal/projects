<?php include('navbars.php'); 
   $id=$_GET['id'];
   
   ?>
<!--		<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered">
   <tr><td><form enctype="multipart/form-data"  action="" id="wb_Form1" name="form" method="post">
   	
   		<input type="file" name="photo" id="photo"  required="required">
   		Information about file:<input type="text" name="info" class="form-control"></td>
   		<td><label text="course" class="form-">course</label><select class="form-control" name="course">
   		
   		<option>--select--</option>				
   		<option value="MCA">MCA</option>
   		<option value="I-MCA">IMCA</option>
   		
   		</select></td>
   		<td><label text="course" class="form-">SEM</label><select class="form-control" name="sem">
   	<option>--select--</option>				
   	<option value="sem-1">sem-1</option>
   	
   	<option value="sem-2">sem-2</option><option value="sem-3">sem-3</option><option value="sem-4">sem-4</option>
   	<option value="sem-4">sem-5</option><option value="sem-4">sem-6</option>
   	</select></td>
   		<td><label text="course" class="form-">class</label><select class="form-control" name="class">
   	<option>--select--</option>				
   	<option value="B">A</option>
   	
   	<option value="B">B</option><option value="C">C</option>
   	</select></td>
   		
   		<td><input type="submit" class="btn btn-danger" value="SUBMIT" name="submit">
   
   </form></tr></td></table>
   -->						
<div class="col-md-18">
   <div class="container-fluid" style="margin-top:0px;">
      <div class = "row">
         <div class="panel panel-default">
            <div class="panel-body">
               <div class="table-responsive">
                  <form method="post" action="delete.php" >
                     <table cellpadding="0" cellspacing="0" border="0" class="table table-condensed" id="example">
                        <thead>
                           <tr style="background-color:grey;color:white">
                              <th>student name</th>
                              <th>Student upload_assignment</th>
                              <th>Marks</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php 
                              ?>
                           <?php
                              $query=mysql_query("select * from marks u ,tbl_stud s ,upload_student a where a.stud_id='$id' && s.sid='$id' && u.stud_id ='$id'")or die(mysql_error());
                              while($row=mysql_fetch_array($query)){
                              	?>
                           <td> <?php echo $row['sname'] ?></td>
                           <td><?php echo $row['uname'] ?></td>
                           <td><?php echo $row['marks'] ?>/10</td>
                           </tr>
                           <?php } ?>
                        </tbody>
                     </table>
               </div>
               </form>
            </div>
         </div>
      </div>
      <!-- bootstrap js -->
      <!-- slimscroll js -->
      <script type="text/javascript" src="js/vendor/jquery.slimscroll.js"></script>
      <!-- pace js -->
      <script src="js/vendor/pace/pace.min.js"></script>
      <!-- main js -->
      <script src="js/main.js"></script>
      <!-- demo  -->
      <script src="js/appdemo.js"></script>
      <div class="footer-fixed">
         <div class="pull-right">
            <ul class="list-inline">
                <li>Design & Developed By <a href="https://www.facebook.com/panakaj.kalal">Pankaj kalal</a> & <a href="https://www.facebook.com/lal.saroj.1">Sarojkumar Lal</a></li>
           
            </ul>
         </div>
         <div> <strong>Copyright</strong>  &copy; LJMCA </div>
      </div>
   </div>
</div>
</body>
</html>