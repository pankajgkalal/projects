<?php
session_start();
$conn = mysqli_connect("localhost","root","","myweb");
    $marks=$_POST['marks']; 
   $sid=$_SESSION['sid'];//username
	 $aid=$_SESSION['aid'];//password 

//echo "Insert into tbl_test(fname,lname) values('$a','$b')";
if(mysqli_query($conn,"INSERT INTO `marks`(`marks`, `stud_id`, `assign_id`) VALUES('$marks','$sid','$aid')"))
{
	echo "Done";

header ("location:index.php");
	}
else
{
	echo mysqli_error($conn);
}
?>