<?php include('navbarsupload.php'); ?>
<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered">
   <tr>
      <td>
         <form enctype="multipart/form-data"  action="" id="wb_Form1" name="form" method="post">
            <input type="file" name="photo" id="photo"  required="required" class="custom-file-input">
            Information about file:<input type="text" name="info" class="form-control">
      </td>
      <td><label text="course" class="form-">course</label><select class="form-control" name="course">
      <option value="0">Select course</option>
      <?php
         $conn = mysqli_connect("localhost","root","","myweb");
         if($result2 = mysqli_query($conn,"Select * from tbl_course"))
         {
          while($row2=$result2->fetch_assoc())
          {
         
         	?>
      <option value="<?php  echo $row2["cname"] ?>"><?php  echo $row2["cname"] ?></option>
      <?php
         }
         }
         
         ?>
      </select></td>
      <td><label text="course" class="form-">SEM
      </label><select class="form-control" name="sem" required>
      <option value="0">Select sem</option>
      <?php
         $conn = mysqli_connect("localhost","root","","myweb");
         if($result2 = mysqli_query($conn,"Select * from tbl_sem"))
         {
          while($row2=$result2->fetch_assoc())
          {
         
         	?>
      <option value="<?php  echo $row2["sem"] ?>"><?php  echo $row2["sem"] ?></option>
      <?php
         }
         }
         
         ?>
      </select>
      </td>
      <td><label text="course" class="form-">class</label><select class="form-control" name="class" required>
      <option>--select--</option>				
      <option value="A">A</option>
      <option value="B">B</option><option value="C">C</option>
      <option value="C">D</option>
      </select></td>
      <td><input type="submit" class="btn btn-danger" value="SUBMIT" name="submit" style="margin-top:20px">
      </form>
   </tr>
   </td>
</table>
<div class="col-md-18">
   <div class="container-fluid" style="margin-top:0px;">
      <div class = "row">
         <div class="panel panel-default">
            <div class="panel-body">
               <div class="table-responsive">
                  <form method="post" action="delete.php" >
                     <table cellpadding="0" cellspacing="0" border="0" class="table table-condensed" id="example">
                        <thead>
                           <tr style="background-color:grey;color:white">
                              <th>FILE NAME</th>
                              <th>Date</th>
                              <th>Description</th>
                              <th>Course</th>
                              <th>Sem</th>
                              <th>Download</th>
                              <th>Remove</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php 
                              $con=mysqli_connect("localhost","root","","myweb");//mysqli("localhost","username of database","password of database","database name")
                              //$student_id=$_GET["student_id"];
                              //$student_email=$_GET["student_email"];
                              
                              if($result2=mysqli_query($con,"SELECT * FROM tbl_student where (semail='$Email' && spwd='$password')"))
                              {
                              
                               while($row=$result2->fetch_assoc())
                               {
                                  $sem1=$row["sem"] ;
                              		
                              }
                              }
                              ?>
                           <?php
                              $query=mysql_query("select * from upload  ")or die(mysql_error());
                              while($row=mysql_fetch_array($query)){
                              $id=$row['id'];
                              $name=$row['name'];
                              $date=$row['date'];
                              ?>
                           <tr>
                              <td><?php echo $row['name'] ?></td>
                              <td><?php   $date= $row["date"];
                                 echo date('d-m-Y', strtotime($date));?>
                              </td>
                              <td><?php echo $row['info'] ?></td>
                              <td><?php echo $row['course'] ?></td>
                              <td><?php echo $row['sem'] ?></td>
                              <td>
                                 <a href="download.php?filename=<?php echo $name;?>" title="click to download"><span class="glyphicon glyphicon-paperclip" style="font-size:20px; color:blue"></span></a>
                              </td>
                              <td>
                                 <a href="delete.php?del=<?php echo $row['id']?>"><span class="glyphicon glyphicon-trash" style="font-size:20px; color:red"></span></a>
                              </td>
                           </tr>
                           <?php } ?>
                        </tbody>
                     </table>
               </div>
               </form>
            </div>
         </div>
      </div>
      <div class="footer-fixed">
         <div class="pull-right">
            <ul class="list-inline">
               <li>Design & Developed By <a href="https://www.facebook.com/panakaj.kalal">Pankaj kalal</a> & <a href="https://www.facebook.com/lal.saroj.1">Sarojkumar Lal</a></li>
            </ul>
         </div>
         <div> <strong>Copyright</strong>  &copy; LJMCA </div>
      </div>
   </div>
</div>
</body>
</html>