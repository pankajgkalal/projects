<?php


$db = mysql_connect("localhost","root","") or die ("Unable to connect to Localhost");
mysql_select_db("myweb") or die ("Could not select the database.");


?>