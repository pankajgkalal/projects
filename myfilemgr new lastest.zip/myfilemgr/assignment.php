<?php include('navbar.php'); ?>
<table cellpadding="0" cellspacing="0" border="0" class="table table-bordered">
   <tr>
      <td>
         <form enctype="multipart/form-data"  action="" id="wb_Form1" name="form" method="post">
            <input type="file" name="photo" id="photo"  required="required">
            Information about file:<input type="text" name="info" class="form-control">
      </td>
      <td><label text="course" class="form-">course</label><select class="form-control" name="course">
      <option>--select--</option>				
      <option value="MCA">MCA</option>
      <option value="I-MCA">IMCA</option>
      </select></td>
      <td><label text="course" class="form-">SEM</label><select class="form-control" name="sem">
      <option>--select--</option>				
      <option value="sem-1">sem-1</option>
      <option value="sem-2">sem-2</option><option value="sem-3">sem-3</option><option value="sem-4">sem-4</option>
      <option value="sem-4">sem-5</option><option value="sem-4">sem-6</option>
      </select></td>
      <td><label text="course" class="form-">class</label><select class="form-control" name="class">
      <option>--select--</option>				
      <option value="B">A</option>
      <option value="B">B</option><option value="C">C</option>
      </select></td>
      <td><input type="submit" class="btn btn-danger" value="SUBMIT" name="submit" style="margin-top:22px">
      </form>
   </tr>
   </td>
</table>
<div class="col-md-20">
   <div class="container-fluid" style="margin-top:0px;">
      <div class = "row">
         <div class="panel panel-default">
            <div class="panel-body">
               <div class="table-responsive">
                  <form method="post" action="delete.php" >
                     <table cellpadding="0" cellspacing="0" border="0" class="table table-condensed" id="example">
                        <thead>
                           <tr style="background-color:grey;color:white">
                              <th>FILE NAME</th>
                              <th>Date</th>
                              <th>Description</th>
                              <th>Course</th>
                              <th>Sem</th>
                              <th>Download</th>
                              <th>Remove</th>
                              <th>Assignment</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php 
                              $con=mysqli_connect("localhost","root","","myweb");//mysqli("localhost","username of database","password of database","database name")
                              //$student_id=$_GET["student_id"];
                              //$student_email=$_GET["student_email"];
                              
                              if($result2=mysqli_query($con,"SELECT * FROM tbl_student where (semail='$Email' && spwd='$password')"))
                              {
                              
                               while($row=$result2->fetch_assoc())
                               {
                                  $sem1=$row["sem"] ;
                              		
                              }
                              }
                              ?>
                           <?php
                              $query=mysql_query("select * from upload_assignment where f_id ='$fid'")or die(mysql_error());
                              while($row=mysql_fetch_array($query)){
                              $id=$row['id'];
                              $name=$row['name'];
                              $date=$row['date'];
                              ?>
                           <tr>
                              <td><?php echo $row['name'] ?></td>
                              <td><?php   $date= $row["date"];
                                 echo date('d-m-Y', strtotime($date));?>
                              </td>
                              <td><?php echo $row['info'] ?></td>
                              <td><?php echo $row['course'] ?></td>
                              <td><?php echo $row['sem'] ?></td>
                              <td>
                                 <a href="download.php?filename=<?php echo $name;?>" title="click to download"><span class="glyphicon glyphicon-paperclip" style="font-size:20px; color:blue"></span></a>
                              </td>
                              <td>
                                 <a href="delete.php?del=<?php echo $row['id']?>"><span class="glyphicon glyphicon-trash" style="font-size:20px; color:red"></span></a>
                              </td>
                              <td>
                                 <a href="vs.php?id=<?php echo $row["id"] ?>" >View_submission</a>
                              </td>
                           </tr>
                           <?php } ?>
                        </tbody>
                     </table>
               </div>
               </form>
            </div>
         </div>
      </div>
      <div class="footer-fixed">
         <div class="pull-right">
            <ul class="list-inline">
                 <li>Design & Developed By <a href="https://www.facebook.com/panakaj.kalal">Pankaj kalal</a> & <a href="https://www.facebook.com/lal.saroj.1">Sarojkumar Lal</a></li>
           
            </ul>
         </div>
         <div> <strong>Copyright</strong>  &copy; LJMCA </div>
      </div>
   </div>
</div>
</body>
</html>