# -*- coding: utf-8 -*-
"""
Created on Sun Apr 14 09:52:51 2019

@author: shiva
"""

from scipy.stats import ttest_ind
import numpy as np
import pandas as pd

df = pd.read_csv(r"C:\Users\shiva\Documents\ndsap_visa_info_JAN_2014.csv")
#sb.pairplot(df)
tourist=df.groupby(['COUNTRY'])[["TOURIST"]].sum()
business=df.groupby(['COUNTRY'])[["BUSINESS_VISA_IN_NO"]].sum()
"""print(week1)
print("week2 data :-\n")
print(week2)"""
tourist_mean = np.mean(tourist)
business_mean = np.mean(business)
print("Tourist mean value:",tourist_mean)
print("Business mean value:",business_mean)
tourist_std = np.std(tourist)
business_std = np.std(business)
print("Tourist std value:",tourist_std)
print("Business std value:",business_std)
ttest,pval = ttest_ind(tourist,business)
print("p-value",pval)
if pval <0.05:
  print("we reject null hypothesis")
else:
  print("we accept null hypothesis")
  
  