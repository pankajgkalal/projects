import sys
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from collections import Counter
df = pd.read_csv(r"C:\Users\shiva\Documents\ndsap_visa_info_JAN_2014.csv")
country=df.groupby(['VISA_ISSUE_DATE'])
fig,ax=plt.subplots(figsize=(120,60))
plt.suptitle('Tourist visa by country')
plt.xticks(rotation=42)
df.boxplot(by='COUNTRY',column=['TOURIST'],ax=ax)

plt.show()
